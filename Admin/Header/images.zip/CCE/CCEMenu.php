<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="en-us" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>CCE Menu</title>

</style>
</head>

<body>

		<table border="1" width="100%" bordercolor="#000000" id="table3"  style="border-width: 0px">

			<tr>

				<td  style="border-style:none; border-width:medium; height: 5px">

				<div >

				<font face="Cambria" style="font-size: 12pt">

				<strong>CCE Based Report Card Generation and Grades Management</strong></font></div>
<hr  style="height: -15px">
<p  style="height: 7px">
<font face="Cambria" style="font-size: 12pt"><a href="javascript:history.back(1)">
<img height="30" src="../images/BackButton.png" width="70" style="float: right"></a></font></p>
				
				</td>

			</tr>

		</table>

		<div id="layer4" style="position: absolute; width: 294px; height: 388px; z-index: 1; left: 347px; top: 68px">

				<strong><span style="font-family: Cambria; font-weight: 700">
				Descriptive Grades Upload</span><span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" ><hr>

				</span>

				</strong>
				<p><font face="Cambria" style="font-size: 12pt"><strong>
				<a href="frmFetchStudentDetail.php">Descriptive Indicator Upload</a></strong><br />
				<br />

				</font><font face="Cambria" color="#C0C0C0">Modify Points and 
				Grades Values</font><p><span ><strong>
				
				<span style="font-size: 12pt">
				<span style="font-family: Cambria; font-weight: 700" >
				<a href="frmFetchCCEStatus.php">
				Descriptive Indicator Report Card Upload Status</a></a></span><span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" ><br />
			<br />
			</span>

				</span>

				</strong></span><font face="Cambria" color="#C0C0C0">Class wise 
				and Student Wise Descriptive Indicator Report Card Preparation Status</font><span ><strong><font color="#C0C0C0" face="Cambria">

				</font></strong></span><p><span ><strong>
				
				<span style="font-size: 12pt">
				<span style="font-family: Cambria; font-weight: 700" >
				<a href="frmFetchCCEMarksUploadStatus.php">
				Marks Upload Status</a></a></span><span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" ><br />
			<br />
			</span>

				</span>

				</strong></span><font face="Cambria" color="#C0C0C0">Class wise 
				and Student Wise Marks Upload Status</font><span ><strong><font color="#C0C0C0" face="Cambria">

				</font></strong></span><p><span ><strong>
				
				<span style="font-size: 12pt">
				<span style="font-family: Cambria; font-weight: 700" >
				<a href="ReportCardPrimary.php">
				Primary Section Report Card Upload Status</a></a></span><span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" ><br />
			<br />
			</span>

				</span>

				</strong></span><font face="Cambria" color="#C0C0C0">Class wise 
				and Student Wise Report Card Preparation Status</font><span ><strong><font color="#C0C0C0" face="Cambria">

				</font></strong></span></div>

		<p>&nbsp;</p>
		<p >&nbsp;</p>
		<div id="layer2" style="position: absolute; width: 289px; height: 472px; z-index: 1; left: 680px; top: 68px">

				<strong><span style="font-family: Cambria; font-weight: 700">
				Descriptive Indicators Management</span><span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" ><hr>

				</span>

				</strong>
				<p><strong><a href="frmFeeCollectionRpt.php">
				<font face="Cambria">Class wise Points &amp; Grades Mapping</font></a></strong><font face="Cambria" style="font-size: 12pt"><br />
				<br />

				</font><font face="Cambria" color="#C0C0C0">Modify Points and 
				Grades Values</font><p><strong>
				<a href="ShowLifeskills_indicators.php">
				<font face="Cambria">Life Skills Descriptive Indicators</font></a></strong><font face="Cambria" style="font-size: 12pt"><br />
				<br />

				</font><span >

				<font face="Cambria" color="#C0C0C0">Active or Life Skills 
				Descriptive Indicators</font></span><font face="Cambria" style="font-size: 12pt"><br />
				<br />

				</font><strong>

				<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF">

				<a href="ShowAttitudevalues_indicators.php">

				<span >Attitude &amp; Values Descriptive Indicators</span></a></span><font face="Cambria"></span></font><span style="font-size: 12pt; font-family:Cambria; font-weight:700; color:#FFFFFF"><br />
				</span>
				<span style="font-size: 12pt"><font color="#C0C0C0">
				<span style="font-family: Cambria; font-weight: 700; " >
			<br />
				</span></font></span></strong><font face="Cambria"></span>

				</font>

				<span >

				<font face="Cambria" color="#C0C0C0">Active or Deactivate 
				Attitude &amp; Values Related Descriptive Indicators</font><strong><font face="Cambria"><span style="font-size: 12pt"><br />
				<br />

				</span></font></strong></span><strong>

				<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" >

				<a href="ShowCoscholisticactivities_indicators.php">
				Co - Scholastic Activities Descriptive Indicators</a></span><span style="font-size: 12pt"><font color="#C0C0C0"><span style="font-family: Cambria; font-weight: 700; " ><br />
				</span></font></span></strong><span >

				<font face="Cambria" color="#C0C0C0">Active or Deactivate Co - 
				Scholastic Descriptive Indicators</font></span><p><strong>

				<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF">

				<a href="ShowHealthphysical_indicators.php">

				<span >Health and Values Descriptive Indicators</span></a></span><font face="Cambria"></span></font><span style="font-size: 12pt; font-family:Cambria; font-weight:700; color:#FFFFFF"><br />
				</span>
				<span style="font-size: 12pt"><font color="#C0C0C0">
				<span style="font-family: Cambria; font-weight: 700; " >
			<br />
				</span></font></span></strong><font face="Cambria"></span>

				</font>

				<span >

				<font face="Cambria" color="#C0C0C0">Active or Deactivate Health 
				and Values Related Descriptive Indicators</font></div>

				</span>

				<strong>
		<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; ">
		<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; ">
		<div id="layer6" style="position: absolute; width: 293px; height: 266px; z-index: 1; left: 348px; top: 514px">

				Marksheet &amp; Evidence of Assessment<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" ><hr>
				<p>
				<span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" >

				<a href="../Academics/frmEvidenceOfAssessment.php">Evidence of 
				Assessment</a></span></span><span style="font-size: 12pt; font-family:Cambria; font-weight:700; color:#FFFFFF"><br />
			<br />
				</span>

				</span></span>
			
				</strong>
				<font color="#C0C0C0" face="Cambria"><span>View Classwise 
				Evidence of Assessment for All Classes :</span></font></p>
				<p>
				<font color="#C0C0C0" face="Cambria"><span>&nbsp;- Top 5</span></font></p>
				<p>
				<font color="#C0C0C0" face="Cambria"><span>- Middle 5</span></font></p>
				<p>
				<font color="#C0C0C0" face="Cambria"><span>- Bottom 5</span></font></p></div>

				<strong>
		<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; ">
		<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; ">
		<div id="layer5" style="position: absolute; width: 288px; height: 266px; z-index: 1; left: 23px; top: 356px">

				Marksheet &amp; </span>
				<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; " >
				Final Report Card</span><span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" ><hr>
				<p>
				<span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" >

				<a href="frmFetchStudentDetailForReportCard.php">View Final Report 
				Card for Term1</a></span></p></span></span>
			
				</strong>
				<p>
				<font face="Cambria" color="#C0C0C0">View Final report Card for 
				Term1</font></p>
				<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" >
		<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; ">

				<strong>
				<p>
				<span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" >

				<a href="frmFetchStudentDetailForReportCard.php">View Final Report 
				Card for Term2</a></span></p>
			
				</strong>
				</span></span>
				<p>
				<font face="Cambria" color="#C0C0C0">View Final report Card for 
				Term1</font></p>
		<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; ">

				<strong>
				<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" >
				<p>
				<span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" >

				<a href="../Academics/frmFinalResult.php">View Marksheet of 
				Term1</a></span></span><span style="font-size: 12pt; font-family:Cambria; font-weight:700; color:#FFFFFF"><br />
			<br />
				</span>

				</strong>
				</span><font color="#C0C0C0" face="Cambria"><span>View Mark 
				sheet for Term1 <br>
				that Will Contain Marks For FA1, FA2 &amp; S1</span></font></p>
		<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; ">

				<strong>
				<p>
			
				<span style="font-family: Cambria; font-weight: 700; color: #FFFFFF; font-size:12pt" >

				<a href="../Academics/frmFinalResult.php">View Marksheet of 
				Term2</a><br />
				</span>
			
				</strong>
				</span><font color="#C0C0C0" face="Cambria"><span>View Marksheet 
				for Term2 <br>
				that Will Contain Marks For all Assessments<br />

				&nbsp;</span></font><strong><span style="font-family: Cambria; font-weight: 700; font-size: 12pt; "><span style="font-family: Cambria; font-weight: 700; font-size: 15px; color: #FFFFFF" ></div>

		</span>
		<div id="layer1" style="position: absolute; width: 288px; height: 266px; z-index: 1; left: 23px; top: 67px">

				Formative &amp; Summative Marks Upload</span><span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" ><hr>
				<p>
				<span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" >

				<a href="../Academics/frmNewReportCard.php">Student Wise Assessment Marks Upload</a></span><font face="Cambria"></span></font><span ><span style="font-size: 12pt; font-family:Cambria; font-weight:700; color:#FFFFFF"><br />
			<br />
				</span>

				<font color="#C0C0C0">
				<span style="font-size: 12pt; font-family:Cambria; ">
				</span></font></span>
			
				</strong>
				<font color="#C0C0C0" face="Cambria"><span>Upload 
				marks for FA1 / FA2 / FA3 / FA4 /SA1 / SA2</span></font></p>
			
				<p>
			
				<span >

				<strong>
				<span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF">

				<a href="../Academics/frmBulkReportCard.php">Subject Wise Assessment Marks Upload</a><span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" ><br />
			<br />
				</span></span></strong></span>
				<font face="Cambria" color="#C0C0C0">Upload Subject Wise Marks 
				for FA1 / FA2 / FA3 / FA4 / SA1 / SA2</font><span style="font-size: 12pt; font-family:Cambria"><strong><br />

				&nbsp;</strong></span></div><strong>
		<div id="layer3" style="position: absolute; width: 259px; height: 304px; z-index: 1; left: 998px; top: 67px">

				<span style="font-family: Cambria">Grades Management</span><span style="font-family: Cambria; font-weight: 700; font-size: 12pt; color: #FFFFFF" ><hr>

				</span>

				<p><font face="Cambria">
				<a href="AssessmentGradeMaster.php">
				Examination Types and Maximum Marks Definition</a></font></p>
				</strong>
				<p>
				<font color="#C0C0C0" face="Cambria"><span>Modify Exam Type &amp; Maximum 
				Marks for FA1 / FA2 / FA3 / FA4 / SA1 / SA2</span></font></p>
				<strong>
				<p><span >

				<span style="font-size: 12pt">
				<span style="font-family: Cambria; font-weight: 700; color: #FFFFFF" >

				

				<a href="GradeMaster.php">

				

				Formative and Summative Assessment Grade Masters</a></span><font face="Cambria"><br />
				<font color="#C0C0C0">
			<br />
				</font></font>
				</span></span>
				</strong><span><font face="Cambria" color="#C0C0C0">Modify Grade 
				Points &amp; Grades Mapping for Formative &amp; Summative Assessment</font></span></p></div>
		
		</body>

</html>