﻿
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Part - 1 Academic Performance</title>
<style type="text/css">
.style1 {
	border-collapse: collapse;
	border: 1px solid #000000;
}
.style3 {
	text-align: center;
	font-family: Arial;
	font-size: 14pt;
	border: 1px solid #000000;
}
.style4 {
	font-family: Arial;
	font-size: 11pt;
	text-align: center;
	border: 1px solid #000000;
}
.style6 {
	font-family: Arial;
	font-size: large;
	border: 1px solid #000000;
}
.style7 {
	font-size: small;
}
.style8 {
	border: 1px solid #000000;
	font-family: Arial;
	font-size: 14pt;
}
</style>
</head>

<body>

<table style="width: 1111px" class="style1">
	<tr>
		<td class="style6" style="height: 50px" colspan="4"><strong>Part - 2 Co-Scholastic Areas<span class="style7">
		</span></strong><span class="style7">(to be assessed on a 5 point scale 
		once in a session)</span><strong><br>2 (A : Life Skills)</b></strong></td>
	</tr>
	<tr>
		<td class="style8" style="width: 85px; height: 50px"><strong>S. No.</strong></td>
		<td class="style3" style="height: 50px"><strong>Descriptive Indicators</strong></td>
		<td class="style3" style="height: 50px"><strong>Description</strong></td>
		<td class="style3" style="height: 50px"><strong>Grade</strong></td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">01</td>
		<td class="style4" style="height: 50px; ">Self Awareness :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">02</td>
		<td class="style4" style="height: 50px; ">Problem Solving :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">03</td>
		<td class="style4" style="height: 50px; ">Decision Making :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">04</td>
		<td class="style4" style="height: 50px; ">Critical Thinking :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">05</td>
		<td class="style4" style="height: 50px; ">Creative Thinking :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">06</td>
		<td class="style4" style="height: 50px; ">Interpersonal Relationships :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">07</td>
		<td class="style4" style="height: 50px; ">Effective Communication :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">08</td>
		<td class="style4" style="height: 50px; ">Empathy :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">09</td>
		<td class="style4" style="height: 50px; ">Managing Emotions :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">10</td>
		<td class="style4" style="height: 50px; ">Dealing with Stress :</td>
		<td class="style4" style="height: 50px">ssss</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
</table>

</body>

</html>