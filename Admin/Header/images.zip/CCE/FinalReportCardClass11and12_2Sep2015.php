<?php

include '../../Connection.php';
include '../../AppConf.php';
?>

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 1</title>
</head>

<body>

<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
	<tr>
		<td colspan="5">
		<p align="center"><font face="Cambria">
		<img src= "../images/logo.png" width="370" height="85"></font></p></td></tr>
		
			<tr><td colspan="5" align="center"><font face="cambria" ><?php echo $SchoolAddress; ?></font></td></tr>

	<tr>
		<td colspan="5">
		<p align="center"><b><font face="Cambria">Assessment Of Assessment I - 
		(2015 - 16)</font></b></td></tr>
		
	
	
	<tr>
		<td width="45" style="border-right-style: none; border-right-width: medium"><b><font face="Cambria">Name</font></b></td>
		<td width="369" style="border-left-style: none; border-left-width: medium">
		: </td>
		<td width="106" style="border-right-style: none; border-right-width: medium"><b><font face="Cambria">Father Name</font></b></td>
		<td width="335" style="border-left-style: none; border-left-width: medium">
		: </td>
	</tr>
	
	<tr>
		<td width="45" style="border-right-style: none; border-right-width: medium"><b><font face="Cambria">Class</font></b></td>
		<td width="369" style="border-left-style: none; border-left-width: medium">
		: </td>
		<td width="106" style="border-right-style: none; border-right-width: medium"><b><font face="Cambria">Roll No</font></b></td>
		<td width="335" style="border-left-style: none; border-left-width: medium">
		: </td>
	</tr>
</table>

<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse; border-top-width:0px">
	<tr>
		<td align="center" colspan="9" style="border-top-style: none; border-top-width: medium">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" width="165" bgcolor="#339933">
		&nbsp;</td>
		<td align="center" width="639" bgcolor="#339933" colspan="2">
		<font face="Cambria" color="#FFFFFF"><b>UT</b></font></td>
		<td align="center" width="764" bgcolor="#339933" colspan="4">
		<b><font face="Cambria" color="#FFFFFF">Term 1</font></b></td>
		<td align="center" width="166" bgcolor="#339933" colspan="2">
		<font face="Cambria" color="#FFFFFF"><b>Term1 + UT</b></font></td>
	</tr>
	<tr>
		<td width="165">
		<p align="center">
		<b><font face="Cambria">Subject</font></b></td>
		<td width="330" align="center" colspan="2">&nbsp;</td>
		<td width="402" colspan="2" align="center"><font face="Cambria"><b>
		Theory</b></font></td>
		<td width="401" colspan="2" align="center"><font face="Cambria"><b>
		Practical</b></font></td>
		<td width="166" colspan="2">
		<p align="center"><font face="Cambria"><b>Total</b></font></td>
	</tr>
	<tr>
		<td width="165">&nbsp;</td>
		<td width="165" align="center"><b><font face="Cambria">M.M</font></b></td>
		<td width="165" align="center"><b><font face="Cambria">M.O</font></b></td>
		<td width="166" align="center"><font face="Cambria"><b>M.M</b></font></td>
		<td width="166" align="center"><font face="Cambria"><b>M.O</b></font></td>
		<td width="166" align="center"><font face="Cambria"><b>M.M</b></font></td>
		<td width="166" align="center"><font face="Cambria"><b>M.O</b></font></td>
		<td width="83" align="center"><b><font face="Cambria">M.M</font></b></td>
		<td width="83" align="center"><b><font face="Cambria">M.O</font></b></td>
	</tr>
</table>
<br>
<table border="1" width="1327" cellspacing="0" cellpadding="0" style="border-width:0px; border-collapse: collapse">
	<tr>
		<td width="442" style="border-style: none; border-width: medium"><b><font face="Cambria">Class Teacher</font></b></td>
		<td width="442" style="border-style: none; border-width: medium">
				<p align="center">
				<b><font face="Cambria">Coordinator</font></b><td width="443" style="border-style: none; border-width: medium">
		<p align="right"><font face="Cambria"><b>Principal</b></font></td>

	
	</tr>
	<tr>
		<td width="442" style="border-style: none; border-width: medium">&nbsp;</td>
		<td width="442" style="border-style: none; border-width: medium">
				&nbsp;<td width="443" style="border-style: none; border-width: medium">&nbsp;</td>

	
	</tr>
	<tr>
		<td width="442" style="border-style: none; border-width: medium">
		______________</td>
		<td width="442" style="border-style: none; border-width: medium">
				<p align="center">________________<td width="443" style="border-style: none; border-width: medium">
		<p align="right">________________</td>

	
	</tr>
	</table>

</body>

</html>
