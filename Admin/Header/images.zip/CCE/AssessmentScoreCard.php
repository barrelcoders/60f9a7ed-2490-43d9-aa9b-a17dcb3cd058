﻿
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Part - 1 Academic Performance</title>
<style type="text/css">
.style1 {
	border-collapse: collapse;
	border: 1px solid #000000;
}
.style2 {
	border: 1px solid #000000;
}
.style3 {
	text-align: center;
	font-family: Arial;
	font-size: 14pt;
	border: 1px solid #000000;
}
.style4 {
	font-family: Arial;
	font-size: 11pt;
	text-align: center;
	border: 1px solid #000000;
}
.style5 {
	font-family: Arial;
	font-size: 12pt;
	text-align: center;
	border: 1px solid #000000;
}
.style6 {
	font-family: Arial;
	font-size: large;
	border: 1px solid #000000;
}
</style>
</head>

<body>

<table style="width: 1111px" class="style1">
	<tr>
		<td class="style6" style="height: 50px" colspan="13"><strong>Part - 1 
		Academic Performance : Scholastic Areas<br>(9 point scale)</b></strong></td>
	</tr>
	<tr>
		<td class="style2" style="width: 85px; height: 50px">&nbsp;</td>
		<td class="style2" style="width: 85px; height: 50px">&nbsp;</td>
		<td class="style3" colspan="4" style="height: 50px"><strong>Term - I</strong></td>
		<td class="style3" colspan="4" style="height: 50px"><strong>Term - II</strong></td>
		<td class="style3" colspan="3" style="height: 50px"><strong>(Term - I + 
		II)</strong></td>
	</tr>
	<tr>
		<td class="style5" style="width: 85px; height: 50px"><strong>S.No.</strong></td>
		<td class="style5" style="width: 85px; height: 50px"><strong>Subjects</strong></td>
		<td class="style5" style="height: 50px; width: 85px">FA 1</td>
		<td class="style5" style="width: 85px; height: 50px">FA 2</td>
		<td class="style5" style="width: 85px; height: 50px">SA 1</td>
		<td class="style5" style="width: 85px; height: 50px">&nbsp;</td>
		<td class="style5" style="width: 85px; height: 50px">FA 3</td>
		<td class="style5" style="width: 85px; height: 50px">FA 4</td>
		<td class="style5" style="width: 85px; height: 50px">SA 2</td>
		<td class="style5" style="width: 86px; height: 50px">&nbsp;</td>
		<td class="style5" style="width: 86px; height: 50px">&nbsp;</td>
		<td class="style5" style="width: 86px; height: 50px">&nbsp;</td>
		<td class="style5" style="width: 86px; height: 50px">Overall Grade</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">01</td>
		<td class="style4" style="width: 85px; height: 50px">Hindi</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">02</td>
		<td class="style4" style="width: 85px; height: 50px">English</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">03</td>
		<td class="style4" style="width: 85px; height: 50px">Sanskrit</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">04</td>
		<td class="style4" style="width: 85px; height: 50px">Mathematics</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">05</td>
		<td class="style4" style="width: 85px; height: 50px">Science</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">06</td>
		<td class="style4" style="width: 85px; height: 50px">Social Science</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">07</td>
		<td class="style4" style="width: 85px; height: 50px">Computer</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">08</td>
		<td class="style4" style="width: 85px; height: 50px">Drawing</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">09</td>
		<td class="style4" style="width: 85px; height: 50px">G.K.s</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
	<tr>
		<td class="style4" style="width: 85px; height: 50px">10</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="height: 50px; width: 85px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 85px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
		<td class="style4" style="width: 86px; height: 50px">s</td>
	</tr>
</table>

</body>

</html>
