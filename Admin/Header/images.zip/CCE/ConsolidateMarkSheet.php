<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Term1 Marks Assessment for Class</title>
</head>

<body>

<p align="center"><b><font face="Cambria">Term1 Marks Assessment for Class :</font></b></p>
<table border="1" width="1043" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
	<tr>
		<td width="67">&nbsp;</td>
		<td width="983" colspan="24" align="center"><font face="Cambria"><b>
		Subject1</b></font></td>
	</tr>
	<tr>
		<td width="67" align="center" rowspan="2"><font face="Cambria"><b>Name</b></font></td>
		<td width="99" align="center" colspan="3"><font face="Cambria"><b>FA1</b></font></td>
		<td width="158" align="center" colspan="3"><font face="Cambria"><b>FA2</b></font></td>
		<td width="158" align="center" colspan="3"><font face="Cambria"><b>SA1</b></font></td>
		<td width="158" align="center" colspan="3"><font face="Cambria"><b>Term1</b></font></td>
		<td width="158" align="center" colspan="3"><font face="Cambria"><b>FA3</b></font></td>
		<td width="158" align="center" colspan="3"><font face="Cambria"><b>FA4</b></font></td>
		<td width="158" align="center" colspan="3"><font face="Cambria"><b>SA2</b></font></td>
		<td width="169" align="center" colspan="3"><font face="Cambria"><b>Term2</b></font></td>
	</tr>
	<tr>
		<td width="40" align="center"><font face="Cambria"><b>M</b></font></td>
		<td width="40" align="center"><font face="Cambria"><b>%</b></font></td>
		<td width="40" align="center"><font face="Cambria"><b>G</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>M</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>%</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>G</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>M</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>%</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>G</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>M</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>%</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>G</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>M</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>%</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>G</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>M</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>%</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>G</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>M</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>%</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>G</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>M</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>%</b></font></td>
		<td width="41" align="center"><font face="Cambria"><b>G</b></font></td>
	</tr>
	<tr>
		<td width="67" align="center">&nbsp;</td>
		<td width="40" align="center">&nbsp;</td>
		<td width="40" align="center">&nbsp;</td>
		<td width="40" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
		<td width="41" align="center">&nbsp;</td>
	</tr>
</table>

</body>

</html>
