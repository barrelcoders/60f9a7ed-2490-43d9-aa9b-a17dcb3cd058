<?php
include '../../connection.php';
include '../../AppConf.php';
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>School Name</title>
</head>

<body>
<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
	<tr>
		<td colspan="5">
		<p align="center"><font face="Cambria">
		<img src= "../images/logo.png" width="370" height="85"></font></p></td></tr>
		
			<tr><td colspan="5" align="center"><font face="cambria" style="font-size: 11pt;"><?php echo $SchoolAddress ?>"<br></font></td></tr>

	<tr>
		<td colspan="5">
		<p align="center"><b><font face="Cambria">Evaluation I - 
		(2015 - 16)</font></b></td></tr>
		
	
	
	


<p align="center"><b><font face="Cambria" size="4">Evaluation - 1</font></b></p>
<div align="center">
	<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td width="1172" colspan="4"><u><b>Student Profile:</b></u></td>
		</tr>
		<tr>
			<td width="293"><font face="Cambria">Name </font></td>
			<td width="293">&nbsp;</td>
			<td width="293"><font face="Cambria">Mother's Name</font></td>
			<td width="293">&nbsp;</td>
		</tr>
		<tr>
			<td width="293"><font face="Cambria">Class</font></td>
			<td width="293">&nbsp;</td>
			<td width="293"><font face="Cambria">Father's Name</font></td>
			<td width="293">&nbsp;</td>
		</tr>
		<tr>
			<td width="293"><font face="Cambria">Admission No.</font></td>
			<td width="293">&nbsp;</td>
			<td width="293"><font face="Cambria">Address</font></td>
			<td width="293">&nbsp;</td>
		</tr>
		<tr>
			<td width="293"><font face="Cambria">Date of Birth</font></td>
			<td width="293">&nbsp;</td>
			<td width="293"><font face="Cambria">Mobile</font></td>
			<td width="293">&nbsp;</td>
		</tr>
		<tr>
			<td width="1172" colspan="4">&nbsp;</td>
		</tr>
		<tr>
			<td width="1172" colspan="4"><u><b>Health</b></u></td>
		</tr>
		<tr>
			<td width="293">Health</td>
			<td width="293">&nbsp;</td>
			<td width="293">Weight</td>
			<td width="293">&nbsp;</td>
		</tr>
		<tr>
			<td width="1172" colspan="4">&nbsp;</td>
		</tr>
		<tr>
			<td width="1172" colspan="4"><u><b>Attendance:</b></u></td>
		</tr>
		<tr>
			<td width="293">Total attendance of the studen:</td>
			<td width="293">&nbsp;</td>
			<td width="293">Total working days:</td>
			<td width="293">&nbsp;</td>
		</tr>
		<tr>
			<td width="293">&nbsp;</td>
			<td width="293">&nbsp;</td>
			<td width="293">&nbsp;</td>
			<td width="293">&nbsp;</td>
		</tr>
		</table>
	<p align="center"><b><font face="Cambria" size="4">FIRST EVALUATION (APRIL TO SEPTEMBER)
	</font></b></p>
	<div align="center">
		<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
			<tr>
				<td width="319">
				<font face="Cambria" style="font-size: 14pt"><b>Subject</b></font></td>
				<td align="center" width="321">
				<font face="Cambria" style="font-size: 14pt"><b>Grades</b></font></td>
				<td align="center"><b>
				<font face="Cambria" style="font-size: 14pt">Remarks</font></b></td>
			</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">ENGLISH</font></b></td>
				<td bgcolor="#339933" width="321">&nbsp;</td>
				<td bgcolor="#339933">&nbsp;</td>
			</tr>
			<tr>
				<td width="319">
				<font face="Cambria" style="font-size: 11pt; font-weight: 700">
				Reading Skill</font></td>
				<td width="321">&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Fluency</font></td>
				<td width="321">&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td width="319">
				<font face="Cambria" style="font-size: 11pt; font-weight: 700">
				Writing Skill</font></td>
				<td width="321">&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font face="Cambria" style="font-size: 11pt">Grammar</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font style="font-size: 11pt" face="Cambria">Spelling</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font style="font-size: 11pt; font-weight: 700" face="Cambria">
				Speaking Skill</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font style="font-size: 11pt" face="Cambria">Conversation</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				&nbsp;</td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font style="font-size: 11pt" face="Cambria">Activity/Project</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" colspan="3">&nbsp;</td>
			</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">HINDI</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
			</tr>
			<tr>
				<td width="319">
				<font face="Cambria" style="font-size: 11pt; font-weight: 700">
				Reading Skill</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Fluency</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td width="319">
				<font face="Cambria" style="font-size: 11pt; font-weight: 700">
				Writing Skill</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font face="Cambria" style="font-size: 11pt">Grammar</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font face="Cambria" style="font-size: 11pt">Spelling</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font face="Cambria" style="font-size: 11pt; font-weight: 700">
				Speaking Skill</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font face="Cambria" style="font-size: 11pt">Conversation</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" width="319">
				<font face="Cambria" style="font-size: 11pt">Extra Reading</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" colspan="3">&nbsp;</td>
			</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">MATHS</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
			</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Mental Ability</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Written Work</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="3">&nbsp;</td>
			</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">Environmental 
				Studies</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
			</tr>
			<tr>
				<td width="319"><font style="font-size: 11pt" face="Cambria">
				Activity/Project</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Written Work</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
			</tr>
			<tr>
				<td height="25" colspan="3">&nbsp;</td>
			</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">SCIENCE</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">&nbsp;</td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font style="font-size: 11pt" face="Cambria">
				Concept</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Activity/project</font></td>
				<td height="25" width="321">&nbsp;</td>
				<td height="25">&nbsp;</td>
				</tr>
			<tr>
				<td height="25" colspan="3">&nbsp;</td>
			</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">COMPUTER</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">&nbsp;</td>
				<td height="23" width="321">&nbsp;</td>
				<td height="23">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font style="font-size: 11pt" face="Cambria">
				Skill</font></td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font style="font-size: 11pt" face="Cambria">
				Aptitude</font></td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td colspan="3">&nbsp;</td>
				</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">General Knowledge</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">&nbsp;</td>
				<td height="23" width="321">&nbsp;</td>
				<td height="23">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				General Awareness</font></td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td colspan="3"><br>
&nbsp;</td>
				</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font style="font-size: 11pt" face="Cambria">Talent</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">&nbsp;</td>
				<td height="23" width="321">&nbsp;</td>
				<td height="23">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">Art 
				&amp; Craft</font></td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">Sport</td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td colspan="3">&nbsp;</td>
				</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">Social Sensibility</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">&nbsp;</td>
				<td height="23" width="321">&nbsp;</td>
				<td height="23">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Regularity/Punctuality</font></td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">Personal Hygiene</td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Confidence</font></td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Behaviour with Other</font></td>
				<td height="26" width="321">&nbsp;</td>
				<td height="26">&nbsp;</td>
				</tr>
			<tr>
				<td colspan="3">&nbsp;</td>
				</tr>
			<tr>
				<td width="319" bgcolor="#339933"><b>
				<font face="Cambria" style="font-size: 11pt">Home Work and Study 
				Habits</font></b></td>
				<td height="25" bgcolor="#339933" width="321">&nbsp;</td>
				<td height="25" bgcolor="#339933">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">&nbsp;</td>
				<td height="23" width="321">&nbsp;</td>
				<td height="23">&nbsp;</td>
				</tr>
			<tr>
				<td width="319"><font face="Cambria" style="font-size: 11pt">
				Bring Books &amp; N. Book Regularly</font></td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td width="319">Participates in Class Discussion</td>
				<td height="27" width="321">&nbsp;</td>
				<td height="27">&nbsp;</td>
				</tr>
			<tr>
				<td height="24" colspan="3">&nbsp;</td>
			</tr>
			<tr>
				<td height="23" width="640" colspan="2">
				<font face="Cambria" style="font-size: 12pt; font-weight: 700">
				Class Teacher</font></td>
				<td height="23">
				<p align="right">
				<font face="Cambria" style="font-size: 12pt; font-weight: 700">
				Principal</font></td>
			</tr>
			<tr>
				<td height="23" colspan="3">&nbsp;</td>
			</tr>
			<tr>
				<td height="23" colspan="3">
				<p align="center"><font face="Cambria"><b>A* - Outstanding, A - 
				Excellent, B - Very good, C - Good</b></font></td>
			</tr>
			</table>
		<p>&nbsp;</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

</body>

</html>