<?php include '../Header/Header3.php'; ?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Communications to Students</title>
<style type="text/css">
.footer {
    height:20px; 
    width: 100%; 
    background-image: none;
    background-repeat: repeat;
    background-attachment: scroll;
    background-position: 0% 0%;
    position: fixed;
    bottom: 2pt;
    left: 0pt;
}   
.footer_contents 
{
        height:20px; 
        width: 100%; 
        margin:auto;        
        background-color:Blue;
        font-family: Calibri;
        font-weight:bold;
}
</style>
<script language="JavaScript" fptype="dynamicanimation">
<!--
function dynAnimation() {}
function clickSwapImg() {}
//-->
</script>
<script language="JavaScript1.2" fptype="dynamicanimation" src="file:///C:/Program%20Files/Microsoft%20Office/OFFICE11/fpclass/animate.js">
</script>
</head>

<body onload="dynAnimation()" language="Javascript1.2">


<div style="position: absolute; width: 625px; height: 276px; z-index: 1; left: 624px; top: 143px" id="layer10">
	<table border="1" width="625" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td colspan="3" height="35" bgcolor="#CC3300"><b>
			<font face="Cambria" color="#FFFFFF">Dashboard : Final Report Card 
			Generation Status</font></b></td>
		</tr>
		<tr>
			<td height="35" width="207" align="center"><font face="Cambria">Term</font></td>
			<td height="35" width="208" align="center"><font face="Cambria">
			Class</font></td>
			<td height="35" width="208" align="center"><font face="Cambria">
			Final Report Card</font></td>
			</tr>
	</table>
</div>
<div style="position: absolute; width: 625px; height: 238px; z-index: 1; left: 625px; top: 430px" id="layer1">
	<table border="1" width="625" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td colspan="4" height="35" bgcolor="#CC3300"><b>
			<font face="Cambria" color="#FFFFFF">Dashboard : Toppers In Last 
			Term</font></b></td>
		</tr>
		<tr>
			<td width="155" align="center"><font face="Cambria">Term</font></td>
			<td width="156" align="center"><font face="Cambria">Class</font></td>
			<td width="156" align="center"><font face="Cambria">Student Name</font></td>
			<td width="156" align="center"><font face="Cambria">Marks %</font></td>
		</tr>
		</table>
</div>
<div style="position: absolute; width: 625px; height: 26px; z-index: 1; left: 624px; top: 114px; background-color: #48AC2E" id="layer9">
	<b><font face="Cambria" color="#FFFFFF" style="font-size: 12pt">School News:</font></b></div>
<div style="position: absolute; width: 616px; height: 26px; z-index: 1; left: 1px; top: 114px; background-color: #48AC2E" id="layer8">
	<b><font color="#FFFFFF" face="Cambria" size="3">Upcoming Holidays : </font></b></div>
<div style="position: absolute; width: 603px; height: 276px; z-index: 1; left: 13px; top: 144px" dynamicanimation="fpAnimformatRolloverFP1" fprolloverstyle="background-color: #C0C0C0" onmouseover="rollIn(this)" onmouseout="rollOut(this)" language="Javascript1.2">
	<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td height="35" bgcolor="#0000FF" width="404" colspan="4"><b>
			<font face="Cambria" color="#FFFFFF">Dashboard : Classwise Marks 
			Upload Status</font></b></td>
		</tr>
		<tr>
			<td height="35" width="132" align="center"><font face="Cambria">Term</font></td>
			<td height="35" width="132" align="center"><font face="Cambria">
			Class</font></td>
			<td height="35" width="173" align="center"><font face="Cambria">
			Marks Upload Status</font></td>
			<td height="35" width="165" align="center"><font face="Cambria">
			Indicator Upload Status</font></td>
		</tr>
	</table>
</div>
<div style="position: absolute; width: 603px; height: 238px; z-index: 1; left: 13px; top: 430px" id="layer4">
	<table border="1" width="603" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td colspan="3" height="35" bgcolor="#5B3AB6"><b>
			<font face="Cambria" color="#FFFFFF">Dashboard : Subject wise Marks 
			Upload Status</font></b></td>
		</tr>
		<tr>
			<td width="200" align="center"><font face="Cambria">Class</font></td>
			<td width="200" align="center"><font face="Cambria">Subject</font></td>
			<td width="201" align="center"><font face="Cambria">Marks Upload 
			Status</font></td>
		</tr>
		</table>
</div>

<div class="footer" align="center">
    <div class="footer_contents" align="center">
		<font color="#FFFFFF" face="Cambria">Powered by iSchool Technologies 
		LLP</font></div>
</div>
</body>

</html>