<?php include '../../connection.php'; ?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Primary Section Report Card</title>
</head>

<body>

<p align="center"><b><font size="4" face="Cambria"><?php echo $SchoolName ?></font></b></p>
<p align="center"><b><font size="4" face="Cambria"><?php echo $SchoolAddress ?></font></b></p>
<p align="center"><font face="Cambria"><b><font size="4"><?php echo $SchoolEmailId ?></font>
<p align="center"><image src="../images/logo.png"></image>
<a href="mailto:schoolemail@gmail.com"><font size="4"><?php echo $SchoolWebsite ?></font></a></b></font></p>
<p align="center"><b><font size="4" face="Cambria">Achievement Record for Session : 2014 - 15</font></b></p>
<div align="center">
	<table border="1" width="51%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td width="273"><font face="Cambria"><b>Name</b></font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Class</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Admission No.</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Roll No.</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Gender</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">House</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Date of Birth</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Mother's Name</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Father's Name</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Address</font></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Mobile</font></td>
			<td>&nbsp;</td>
		</tr>
	</table>
	<p align="left"><b><font size="4" face="Cambria">A] ENGLISH</font></b></p>
	<div align="center">
		<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
			<tr>
				<td>&nbsp;</td>
				<td align="center">&nbsp;</td>
				<td align="center"><font face="Cambria"><b>Skills</b></font></td>
				<td align="center" width="182"><b><font face="Cambria">Evaluation-1</font></b></td>
				<td align="center" width="183"><b><font face="Cambria">Evaluation-2</font></b></td>
				<td align="center" width="184"><b><font face="Cambria">Evaluation-3</font></b></td>
			</tr>
			<tr>
				<td rowspan="3"><font face="Cambria">1</font></td>
				<td rowspan="3"><font face="Cambria">Reading Skills</font></td>
				<td><font face="Cambria">Pronunciation</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Fluency</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Comprehension</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td rowspan="5"><font face="Cambria">2</font></td>
				<td rowspan="5"><font face="Cambria">Writing Skills</font></td>
				<td><font face="Cambria">Creative Writing</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Handwriting</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Grammar</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Spelling</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td height="23"><font face="Cambria">Vocabulary</font></td>
				<td height="23" width="182">&nbsp;</td>
				<td height="23" width="183">&nbsp;</td>
				<td height="23" width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">3</font></td>
				<td><font face="Cambria">Speaking Skills</font></td>
				<td><font face="Cambria">Conversation</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><font face="Cambria">Recitation</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">4</font></td>
				<td><font face="Cambria">Listening Skills</font></td>
				<td><font face="Cambria">Comprehension</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">5</font></td>
				<td><font face="Cambria">Extra Reading</font></td>
				<td><font face="Cambria">....</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">6</font></td>
				<td><font face="Cambria">Activity/Project</font></td>
				<td><font face="Cambria">....</font></td>
				<td width="182">&nbsp;</td>
				<td width="183">&nbsp;</td>
				<td width="184">&nbsp;</td>
			</tr>
		</table>
	</div>
</div>
<div align="center">
	<p align="left"><b><font size="4" face="Cambria">B] MOTHER TONGUE</font></b></p>
	<div align="center">
		<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
			<tr>
				<td height="24">&nbsp;</td>
				<td height="24">&nbsp;</td>
				<td height="24">&nbsp;</td>
				<td height="24"><font face="Cambria">Evaluation-1</font></td>
				<td height="24"><font face="Cambria">Evaluation-2</font></td>
				<td height="24"><font face="Cambria">Evaluation-3</font></td>
			</tr>
			<tr>
				<td rowspan="3"><font face="Cambria">1</font></td>
				<td rowspan="3"><font face="Cambria">Reading Skills</font></td>
				<td><font face="Cambria">Pronunciation</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Fluency</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Comprehension</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td rowspan="5"><font face="Cambria">2</font></td>
				<td rowspan="5"><font face="Cambria">Writing Skills</font></td>
				<td><font face="Cambria">Creative Writing</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Handwriting</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Grammar</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">Spelling</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td height="23"><font face="Cambria">Vocabulary</font></td>
				<td height="23">&nbsp;</td>
				<td height="23">&nbsp;</td>
				<td height="23">&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">3</font></td>
				<td><font face="Cambria">Speaking Skills</font></td>
				<td><font face="Cambria">Conversation</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><font face="Cambria">Recitation</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">4</font></td>
				<td><font face="Cambria">Listening Skills</font></td>
				<td><font face="Cambria">Comprehension</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">5</font></td>
				<td><font face="Cambria">Extra Reading</font></td>
				<td><font face="Cambria">....</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td><font face="Cambria">6</font></td>
				<td><font face="Cambria">Activity/Project</font></td>
				<td><font face="Cambria">....</font></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
		</table>
	</div>
</div>
<div align="center">
	<p align="left"><font face="Cambria"><font size="4"><b>C</b></font><b><font size="4">]HEALTH / 
	ATTENDANCE</font></b></font></p>
	<div align="center">
		<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
			<tr>
				<td>&nbsp;</td>
				<td align="center">&nbsp;</td>
				<td align="center">&nbsp;</td>
				<td align="center" width="181"><b><font face="Cambria">
				Evaluation-1</font></b></td>
				<td align="center" width="179"><b><font face="Cambria">
				Evaluation-2</font></b></td>
				<td align="center" width="186"><b><font face="Cambria">
				Evaluation-3</font></b></td>
			</tr>
			<tr>
				<td rowspan="2"><font face="Cambria">1</font></td>
				<td><font face="Cambria">Health</font></td>
				<td><font face="Cambria">Height [cms.]</font></td>
				<td width="181">&nbsp;</td>
				<td width="179">&nbsp;</td>
				<td width="186">&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><font face="Cambria">Weight [kg.]</font></td>
				<td width="181">&nbsp;</td>
				<td width="179">&nbsp;</td>
				<td width="186">&nbsp;</td>
			</tr>
			<tr>
				<td rowspan="2"><font face="Cambria">2</font></td>
				<td><font face="Cambria">Attendance</font></td>
				<td><font face="Cambria">Total Attendance</font></td>
				<td width="181">&nbsp;</td>
				<td width="179">&nbsp;</td>
				<td width="186">&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><font face="Cambria">Attendance Percent</font></td>
				<td width="181">&nbsp;</td>
				<td width="179">&nbsp;</td>
				<td width="186">&nbsp;</td>
			</tr>
		</table>
	</div>
</div>
<p align="left"><font face="Cambria"><font size="4"><b>D</b></font><b><font size="4">]&nbsp; 
MATHEMATICS</font></b></font></p>
<div align="center">
	<table border="1" width="98%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td style="border-top-color: #C0C0C0; border-top-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="184" align="center">
			<b><font face="Cambria">Evaluation-1</font></b></td>
			<td style="border-style: solid; border-width: 1px" width="184" align="center">
			<b><font face="Cambria">Evaluation-2</font></b></td>
			<td style="border-style: solid; border-width: 1px" width="174" align="center">
			<b><font face="Cambria">Evaluation-3</font></b></td>
		</tr>
		<tr>
			<td rowspan="5" style="border-bottom-color: #808080; border-bottom-width: 1px"><font face="Cambria">1</font></td>
			<td rowspan="5" style="border-style: solid; border-width: 1px"><font face="Cambria">Aspects</font></td>
			<td style="border-style: solid; border-width: 1px"><font face="Cambria">Concept</font></td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="174">&nbsp;</td>
		</tr>
		<tr>
			<td style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Activity</font></td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="174">&nbsp;</td>
		</tr>
		<tr>
			<td style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Tables</font></td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="174">&nbsp;</td>
		</tr>
		<tr>
			<td style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Mental Ability</font></td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="174">&nbsp;</td>
		</tr>
		<tr>
			<td style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Written Work</font></td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="184">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="174">&nbsp;</td>
		</tr>
	</table>
</div>
<p align="left"><font face="Cambria"><font size="4"><b>E</b></font><b><font size="4">]&nbsp; 
ENVIRONMENTAL SCIENCE / COMPUTER</font></b></font></p>
<div align="center">
	<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td>&nbsp;</td>
			<td width="156">&nbsp;</td>
			<td width="275">&nbsp;</td>
			<td width="186" align="center"><b><font face="Cambria">Evaluation-1</font></b></td>
			<td width="184" align="center"><b><font face="Cambria">Evaluation-2</font></b></td>
			<td width="186" align="center"><b><font face="Cambria">Evaluation-3</font></b></td>
		</tr>
		<tr>
			<td rowspan="4"><font face="Cambria">1</font></td>
			<td rowspan="4" width="156"><font face="Cambria">EVS</font></td>
			<td width="275"><font face="Cambria">Envi. Sensitivity</font></td>
			<td width="186">&nbsp;</td>
			<td width="184">&nbsp;</td>
			<td width="186">&nbsp;</td>
		</tr>
		<tr>
			<td width="275"><font face="Cambria">Concept</font></td>
			<td width="186">&nbsp;</td>
			<td width="184">&nbsp;</td>
			<td width="186">&nbsp;</td>
		</tr>
		<tr>
			<td width="275"><font face="Cambria">Scientific Skills</font></td>
			<td width="186">&nbsp;</td>
			<td width="184">&nbsp;</td>
			<td width="186">&nbsp;</td>
		</tr>
		<tr>
			<td width="275"><font face="Cambria">Activity / Product</font></td>
			<td width="186">&nbsp;</td>
			<td width="184">&nbsp;</td>
			<td width="186">&nbsp;</td>
		</tr>
		<tr>
			<td rowspan="4"><font face="Cambria">2</font></td>
			<td rowspan="4" width="156"><font face="Cambria">Computer</font></td>
			<td width="275"><font face="Cambria">Group discussion</font></td>
			<td width="186">&nbsp;</td>
			<td width="184">&nbsp;</td>
			<td width="186">&nbsp;</td>
		</tr>
		<tr>
			<td width="275"><font face="Cambria">Written Work</font></td>
			<td width="186">&nbsp;</td>
			<td width="184">&nbsp;</td>
			<td width="186">&nbsp;</td>
		</tr>
		<tr>
			<td width="275"><font face="Cambria">Skills</font></td>
			<td width="186">&nbsp;</td>
			<td width="184">&nbsp;</td>
			<td width="186">&nbsp;</td>
		</tr>
		<tr>
			<td width="275"><font face="Cambria">Aptitude</font></td>
			<td width="186">&nbsp;</td>
			<td width="184">&nbsp;</td>
			<td width="186">&nbsp;</td>
		</tr>
	</table>
</div>
<p align="left"><font face="Cambria"><font size="4"><b>F</b></font><b><font size="4">] CO-CURRICULAR 
ACTIVITIES</font></b></font></p>
<div align="center">
	<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td style="border-top-color: #C0C0C0; border-top-width: 1px">&nbsp;</td>
			<td width="156" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td width="274" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td width="187" style="border-style: solid; border-width: 1px" align="center">
			<b><font face="Cambria">Evaluation-1</font></b></td>
			<td style="border-style: solid; border-width: 1px" width="183" align="center">
			<b><font face="Cambria">Evaluation-2</font></b></td>
			<td style="border-style: solid; border-width: 1px" width="187" align="center">
			<b><font face="Cambria">Evaluation-3</font></b></td>
		</tr>
		<tr>
			<td rowspan="4"><font face="Cambria">1</font></td>
			<td width="156" rowspan="4" style="border-style: solid; border-width: 1px"><font face="Cambria">EVS</font></td>
			<td width="274" style="border-style: solid; border-width: 1px"><font face="Cambria">Enthusiasm</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td width="274" style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Discipline</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td width="274" style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Team Spirit</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td width="274" style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Talent</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td rowspan="3"><font face="Cambria">2</font></td>
			<td rowspan="3" width="156" style="border-style: solid; border-width: 1px"><font face="Cambria">ART / Craft</font></td>
			<td width="274" style="border-style: solid; border-width: 1px"><font face="Cambria">Interest</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td width="274" style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Creativity</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td width="274" style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Skills</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td rowspan="3" style="border-bottom-color: #808080; border-bottom-width: 1px">&nbsp;</td>
			<td width="156" rowspan="3" style="border-style: solid; border-width: 1px"><font face="Cambria">Music / Dance</font></td>
			<td width="274" style="border-style: solid; border-width: 1px"><font face="Cambria">Interest</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td width="274" style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Rhythm</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
		<tr>
			<td width="274" style="border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: solid; border-bottom-width: 1px"><font face="Cambria">Melody</font></td>
			<td width="187" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="183">&nbsp;</td>
			<td style="border-style: solid; border-width: 1px" width="187">&nbsp;</td>
		</tr>
	</table>
</div>
<p align="left"><font face="Cambria"><font size="4"><b>G</b></font><b><font size="4">] PERSONALITY 
DEVELOPMENT</font></b></font></p>
<div align="center">
	<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td>&nbsp;</td>
			<td width="156">&nbsp;</td>
			<td width="273">&nbsp;</td>
			<td width="188" align="center"><b><font face="Cambria">Evaluation-1</font></b></td>
			<td width="182" align="center"><b><font face="Cambria">Evaluation-2</font></b></td>
			<td width="188" align="center"><b><font face="Cambria">Evaluation-3</font></b></td>
		</tr>
		<tr>
			<td rowspan="4"><font face="Cambria">1</font></td>
			<td width="156" rowspan="6"><font face="Cambria">Personal Traits</font></td>
			<td width="273"><font face="Cambria">Courteousness</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Confidence</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Care of belongings</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Neatness</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
		<tr>
			<td rowspan="3"><font face="Cambria">2</font></td>
			<td width="273"><font face="Cambria">Regularity</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Intiative</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
		<tr>
			<td width="156" rowspan="3"><font face="Cambria">Social Traits</font></td>
			<td width="273"><font face="Cambria">Sharing / Caring</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
		<tr>
			<td rowspan="2">&nbsp;</td>
			<td width="273"><font face="Cambria">Respect of Others</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
		<tr>
			<td width="273"><font face="Cambria">Self Contral</font></td>
			<td width="188">&nbsp;</td>
			<td width="182">&nbsp;</td>
			<td width="188">&nbsp;</td>
		</tr>
	</table>
</div>
<p align="left"><font face="Cambria"><font size="4"><b>H</b></font><b><font size="4">] SPECIFIC 
PARTICIPATION AND REMARKS</font></b></font></p>
<div align="center">
	<table border="1" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse">
		<tr>
			<td width="269" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td width="495" style="border-style: solid; border-width: 1px"><font face="Cambria"><b>Specific Participation</b></font></td>
			<td width="210" style="border-style: solid; border-width: 1px"><font face="Cambria"><b>General Remarks</b></font></td>
		</tr>
		<tr>
			<td width="269" style="border-style: solid; border-width: 1px"><font face="Cambria">Evaluation-1</font></td>
			<td width="495" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td width="210" style="border-style: solid; border-width: 1px">&nbsp;</td>
		</tr>
		<tr>
			<td width="269" style="border-style: solid; border-width: 1px"><font face="Cambria">Evaluation-1</font></td>
			<td width="495" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td width="210" style="border-style: solid; border-width: 1px">&nbsp;</td>
		</tr>
		<tr>
			<td width="269" style="border-style: solid; border-width: 1px"><font face="Cambria">Evaluation-1</font></td>
			<td width="495" style="border-style: solid; border-width: 1px">&nbsp;</td>
			<td width="210" style="border-style: solid; border-width: 1px">&nbsp;</td>
		</tr>
	</table>
</div>
<p>&nbsp;</p>
<p><font face="Cambria"><font size="4"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Class Teacher&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</b></font><b><font size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
CCE In-charge&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
Principal</font></b></font></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

</body>

</html>